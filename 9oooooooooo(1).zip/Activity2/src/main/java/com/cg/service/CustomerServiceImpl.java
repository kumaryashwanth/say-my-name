package com.cg.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.dao.CustomerRepository;
@Service
public class CustomerServiceImpl implements ICustomerService {
@Autowired
CustomerRepository customerRepository;
@Autowired
Wallet wallet;
@Autowired
Customer customer;
	@Override
	public Customer createAccount(Customer customer) {
		Wallet newWallet=new Wallet();
		newWallet.setBalance(0.0);
		customer.setWallet(newWallet);
		return customerRepository.save(customer);
	}

	@Override
	public double showBalance(String Mobile_no) {
		return customerRepository.findById(Mobile_no).get().getWallet().getBalance();
	}

	@Override
	public boolean fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		System.out.println(sourceMobileNo+" "+targetMobileNo);
		Customer sourceMobile=customerRepository.findById(sourceMobileNo).get();
		System.out.println("Source"+sourceMobile);
		Customer targetMobile=customerRepository.findById(targetMobileNo).get();
		System.out.println("Target"+targetMobile);
		if(sourceMobile.getWallet().getBalance()<amount.doubleValue()) {
		return false;
		}else {
			Wallet targetWallet=targetMobile.getWallet();
			double targetBalance=targetWallet.getBalance();
			targetBalance=targetWallet.getBalance()+amount.doubleValue();
			targetWallet.setBalance(targetBalance);
			targetMobile.setWallet(targetWallet);
			
			Wallet sourceWallet=sourceMobile.getWallet();
			double sourcebalance=sourceWallet.getBalance();
			sourcebalance=sourceWallet.getBalance()-amount.doubleValue();
			sourceWallet.setBalance(sourcebalance);
			sourceMobile.setWallet(sourceWallet);
			customerRepository.save(sourceMobile);
			customerRepository.save(targetMobile);

			return true;	
		}
		}

	@Override
	public boolean depositAmount(String Mobile_no, BigDecimal amount) {
		customer=customerRepository.findById(Mobile_no).get();
		double balance = customer.getWallet().getBalance() +amount.doubleValue();
		wallet=customer.getWallet();
		wallet.setBalance(balance);
		customer.setWallet(wallet);
		customerRepository.save(customer);
		return true;
	}

	@Override
	public boolean withdrawAmount(String Mobile_no, BigDecimal amount) {
		customer=customerRepository.findById(Mobile_no).get();
		if(customer.getWallet().getBalance()<amount.doubleValue()) {
			return false;	
}else {
	double balance=customer.getWallet().getBalance()-amount.doubleValue();
	wallet=customer.getWallet();
	wallet.setBalance(balance);
	customer.setWallet(wallet);
	customerRepository.save(customer);
	return true;
	
}
		}

	@Override
	public String validateNum(String Mobile_no) {
		String str;
		customer= customerRepository.findById(Mobile_no).get();
		if(customer!=null) {
			str="Mobileno exists";
		}else {
			str="new user";
		}
		return str;
	}

}
